public class Ejercicio1 {

    public static void main(String args[]){

        String nombreCompleto= "Guillermo Manzanero Caldes";

        String PrimerString= nombreCompleto.substring(20,26);

        String SegundoString= nombreCompleto.substring(9,19);

        String inicial= String.valueOf(nombreCompleto.charAt(0));

        System.out.println(PrimerString + SegundoString + ", "+ inicial);


    }
}
