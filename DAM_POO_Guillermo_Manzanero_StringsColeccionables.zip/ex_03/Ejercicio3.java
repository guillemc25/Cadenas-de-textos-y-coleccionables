import java.util.*;

public class Ejercicio3 {

    public static void main(String args[]){

        Scanner sc= new Scanner(System.in);

        System.out.println("Introduce una frase: ");

        String frase= sc.next();

        System.out.println("Introduce un caracter: ");

        char caracter= sc.next().charAt(0);

        System.out.println(" La posición del caracter " + caracter
              +  " de la frase " + frase + " es " +
                BuscarPosición(frase,caracter));


    }

    public static int BuscarPosición(String frase, char caracter){

        for (int i=0; i<frase.length();i++){
            if(frase.charAt(i)== caracter){

                return i + 1;
            }

        }
        return -1;

    };
}
