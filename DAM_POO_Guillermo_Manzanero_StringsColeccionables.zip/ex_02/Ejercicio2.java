import java.util.*;

public class Ejercicio2 {

    public static void main(String arg[]){

        Scanner sc= new Scanner(System.in);

        System.out.println(" introduce la primera cadena: ");

        String cadena1= sc.next();

        System.out.println(" Introduce la segunda cadena ");

        String cadena2= sc.next();

        String cadenaCompleta= cadena1 + cadena2;

        System.out.println(cadenaCompleta);
    }
}
