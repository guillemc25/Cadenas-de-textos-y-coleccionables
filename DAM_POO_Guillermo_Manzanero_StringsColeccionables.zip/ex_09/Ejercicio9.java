import java.util.ArrayList;
import java.util.List;

public class Ejercicio9 {

    public static void main(String args[]){

        List milista = new ArrayList();

        milista.add("Elemento 1");
        milista.add("Elemento 2");

        String[] miarray = new String[milista.size()];

        miarray = (String[]) milista.toArray(miarray);

        for(String s : miarray)
            System.out.println(s);

    }
}
