import java.util.*;
public class Ejercicio4 {

    public static void main(String args[]){

        Scanner sc= new Scanner(System.in);

        System.out.println("Introduce una frase: ");

        String frase= sc.next();

        System.out.println("Introduce un caracter: ");

        char caracter= sc.next().charAt(0);

        int indice= frase.indexOf(caracter) +1;

        System.out.println(" La posición del caracter " + caracter
                +  " de la frase " + frase + " es " +
                indice);
    }
}
