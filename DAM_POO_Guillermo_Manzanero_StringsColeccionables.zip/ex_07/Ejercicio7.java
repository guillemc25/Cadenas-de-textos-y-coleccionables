import java.util.ArrayList;
import java.util.Iterator;

public class Ejercicio7 {

    public static void main(String args[]){
        ArrayList<String> persona = new ArrayList<>();
        persona.add("guille");
        persona.add("Fran");
        persona.add("Anton");


        Iterator<String> it = persona.iterator();

        for(int i=0; i<persona.size();i++){

            System.out.println(it.next());
        }

    }
}
