public class Ejercicio6 {

    public static void main(String args[]){

        String cadena= "Cadenas de texto y coleccionables";

        for(int i=0;i<cadena.length();i++){

            char c= cadena.charAt(i);
            int ascii = c;
            System.out.println("ASCII:"+ ascii + " es equivalente a: "+ c);
       }
    }
}
