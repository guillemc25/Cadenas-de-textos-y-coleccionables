import java.util.HashSet;

public class Ejercicio10 {

    public static void main(String args[]){
        // HashSet declaration
        HashSet<String> hset =
                new HashSet<String>();

        // Adding elements to the HashSet
        hset.add("Apple");
        hset.add("Mango");
        hset.add("Grapes");
        hset.add("Orange");
        hset.add("Fig");

        //No podemos duplicar elementos
        hset.add("Apple");
        hset.add("Mango");

        //permite valores null
        hset.add(null);
        hset.add(null);

        //Displaying HashSet elements
        System.out.println(hset);
    }
}
