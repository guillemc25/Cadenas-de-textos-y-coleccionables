import java.util.ArrayList;
interface lambdas{
    public void iterar();
}
public class Ejercicio8 {

    public static void main(String args[]) {
        ArrayList<String> persona = new ArrayList<>();
        persona.add("guille");
        persona.add("Fran");
        persona.add("Anton");

        lambdas iteracion= () -> {

            for(String s: persona){
                System.out.println(s);
            }


        };

        iteracion.iterar();
    }




}
