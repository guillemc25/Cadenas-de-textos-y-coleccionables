import java.util.*;
import java.util.Scanner;

public class Ejercicio5 {

    public static void main(String args[]) {

        Scanner input = new Scanner(System.in);
        int uppercaseCounter=0;
        int lowercaseCounter=0;
        int digitCounter=0;
        int specialCounter=0;


        System.out.println("Escribe la contraseña: ");

        String password = input.nextLine();
//Contamos cuantas letras mayusculas,minicuculas,caracteres espciales y digitos hay
        for (int i=0; i < password.length(); i++ ) {
            char c = password.charAt(i);
            if(Character.isUpperCase(c))
                uppercaseCounter++;
            else if(Character.isLowerCase(c))
                lowercaseCounter++;
            else if(Character.isDigit(c))
                digitCounter++;
            if(c>=33&&c<=46||c==64){
                specialCounter++;
            }

        }

        if (password.length() >= 8 && uppercaseCounter >= 1
                && lowercaseCounter >= 1 && digitCounter >= 1 && specialCounter >= 1) {
            System.out.println("Contraseña valida");
        }
        else {
            System.out.println("Tu contraseña no contiene:");
            if(password.length() < 8)
                System.out.println("8 caracteres mínimo");
            if (lowercaseCounter < 1)
                System.out.println("Al menos una letra minuscula");
            if (uppercaseCounter < 1)
                System.out.println("Al menos 1 letra mayuscula");
            if(digitCounter < 1)
                System.out.println("Al menos 1 digito");
            if(specialCounter < 1)
                System.out.println("Al menos 1 caracter especial");

        }



    }

        }












